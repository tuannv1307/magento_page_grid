export { default } from "./ColumnPageType";
