export { default } from "./EditMultiDataTask";
