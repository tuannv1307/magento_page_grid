import { st, classes } from "./Dashboard.st.css";
import React from "react";
import Nav from "../Nav/Nav";

const Dashboard = () => {
  return (
    <div className={st(classes.root)}>
      {/* <Nav /> */}
      <div>dawd</div>
    </div>
  );
};

export default Dashboard;
