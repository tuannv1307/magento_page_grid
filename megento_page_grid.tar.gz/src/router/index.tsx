// import { BrowserRouter, Routes, Route } from "react-router-dom";
// import App from "../App";
// import Dashboard from "../components/Dashboard/Dashboard";
// import Products from "../components/Products/Products";

// export default function RoutePage() {
//   return (
//     <BrowserRouter>
//       <Routes>
//         <Route path="/" element={<App />}>
//           <Route path="/products" element={<Products />} />
//         </Route>
//         <Route path="/dashboard" element={<Dashboard />} />
//       </Routes>
//     </BrowserRouter>
//   );
// }
